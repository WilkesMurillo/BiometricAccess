from tkinter import *
from tkinter import ttk
from PIL import Image
from PIL import ImageTk
import numpy as np
import os
import cv2
import imutils
import mediapipe as mp
import datetime
from Conexion import empezar
#################### modelo de reconocimiento facial ###########################################

def api():
    dataPath = './Data'
    imagePaths = os.listdir(dataPath)

 
    face_recognizer = cv2.face.LBPHFaceRecognizer_create()


    face_recognizer.read('modeloLBPHFace.xml')

    faceClassif = cv2.CascadeClassifier(cv2.data.haarcascades+'haarcascade_frontalface_default.xml')

    def decodeImage(pathImage):
        Ruta_dataset = './Dataset_val'
        Test=pathImage
        Ruta=Ruta_dataset + '/' + str(Test) #+ '.jpg'
        frame=cv2.imread(Ruta)
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        auxFrame = gray.copy()
        faces = faceClassif.detectMultiScale(gray,1.3,5)
        for (x,y,w,h) in faces:
            rostro = auxFrame[y:y+h,x:x+w]
            rostro = cv2.resize(rostro,(150,150),interpolation= cv2.INTER_CUBIC)
            result = face_recognizer.predict(rostro)
            cv2.putText(frame,'{}'.format(result),(x,y-5),1,1.3,(255,255,0),1,cv2.LINE_AA)
            # LBPHFace
            if result[1] < 70:
                return imagePaths[result[0]]

            else:
                return ""



#### modelo mediaPipe
def capturar2(nombre):

    personName = (nombre)
    dataPath = './Data' #Cambia a la ruta donde hayas almacenado Data
    personPath = dataPath + '/' + personName

    if not os.path.exists(personPath):
        print('Carpeta creada: ',personPath)
        os.makedirs(personPath)
    
    ## Detector 

    detector = mp.solutions.face_detection
    dibujo = mp.solutions.drawing_utils


    count = 0

    ## video captura

    cap = cv2.VideoCapture(0)

    ## inicializar parametros

    with detector.FaceDetection(min_detection_confidence = 0.75) as rostros:


        while True:
            ret, frame = cap.read()

            # correcion de color

            rgb = cv2.cvtColor(frame , cv2.COLOR_BGR2RGB)

            resultado = rostros.process(rgb)

            if resultado.detections is not None:
                for rostro in resultado.detections:

                    al , an , c = frame.shape

                    xi = rostro.location_data.relative_bounding_box.xmin
                    yi = rostro.location_data.relative_bounding_box.ymin

                    ancho = rostro.location_data.relative_bounding_box.width
                    alto = rostro.location_data.relative_bounding_box.height


                    xi = int(xi * an)
                    yi = int(yi * al)

                    ancho = int(ancho * an)
                    alto = int(alto * al)


                    xf = xi + ancho
                    yf = yi + alto

                    cv2.rectangle(frame, (xi,yi),(xf,yf),(0,255,0),2)


                    cara = frame[yi:yf , xi:xf]


                    cara = cv2.resize(cara, (150, 200) , interpolation= cv2.INTER_CUBIC)


                    cv2.imwrite(personPath + '/rotro_{}.jpg'.format(count), cara)

                    count = count + 1


            cv2.imshow("reconocimiento facial" , frame)



            k = cv2.waitKey(1)
            if k == 27 or count >= 500:
                break

    
    cap.release()
    cv2.destroyAllWindows()
    entrenar()


    

    





#### modelo OpenCv
def capturar(nombre):
    personName = (nombre)
    dataPath = './Data' #Cambia a la ruta donde hayas almacenado Data
    personPath = dataPath + '/' + personName

    if not os.path.exists(personPath):
        print('Carpeta creada: ',personPath)
        os.makedirs(personPath)

    cap = cv2.VideoCapture(0)
    #cap = cv2.VideoCapture('Video.mp4')
    ret, frame = cap.read()

    # Display the resulting frame
    cv2.imshow('frame', frame)

    faceClassif = cv2.CascadeClassifier(cv2.data.haarcascades+'haarcascade_frontalface_default.xml')
    count = 0

    while True:

        ret, frame = cap.read()
        if ret == False: break
        frame =  imutils.resize(frame, width=640)
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        auxFrame = frame.copy()

        faces = faceClassif.detectMultiScale(gray,1.3,5)

        for (x,y,w,h) in faces:
            cv2.rectangle(frame, (x,y),(x+w,y+h),(0,255,0),2)
            rostro = auxFrame[y:y+h,x:x+w]
            rostro = cv2.resize(rostro,(150,150),interpolation=cv2.INTER_CUBIC)
            cv2.imwrite(personPath + '/rotro_{}.jpg'.format(count),rostro)
            count = count + 1
        cv2.imshow('Registro Facial',frame)

        k =  cv2.waitKey(1)
        if k == 27 or count >= 300:
            break


   
    cap.release()
    cv2.destroyAllWindows()
    entrenar()



def entrenar():
    dataPath = './Data' 
    peopleList = os.listdir(dataPath)
    print('Lista de personas: ', peopleList)

    labels = []
    facesData = []
    label = 0

    for nameDir in peopleList:
        personPath = dataPath + '/' + nameDir
        print('Leyendo las imágenes')

        for fileName in os.listdir(personPath):
            print('Rostros: ', nameDir + '/' + fileName)
            labels.append(label)
            facesData.append(cv2.imread(personPath+'/'+fileName,0))
            
        label = label + 1

    

    # Métodos para entrenar el reconocedor
    face_recognizer = cv2.face.LBPHFaceRecognizer_create()

    # Entrenando el reconocedor de rostros
    print("Entrenando...")
    face_recognizer.train(facesData, np.array(labels))

    
    face_recognizer.write('modeloLBPHFace.xml')
    print("Modelo almacenado...")


def persona_reconocida(fueReconocido):
    si="si"
    no="no"
    if fueReconocido==si:
        if gym == 1:
            bienvenido.set("Bienvenido al Gimnasio")
            lugar="Gimnasio"
        elif bibl == 1:
            bienvenido.set("Bienvenido a la Biblioteca")
            lugar="Biblioteca"
        else:
            bienvenido.set("Bienvenido")
            lugar="Puerta Principal"

        infoNombre.set(str(nombre_persona))
        
    elif fueReconocido==no:
        bienvenido.set("No fue posible reconocerte")
        infoNombre.set("Por favor dirigete a información para realizar tu registro") 
    data=[]
    nombre=str(nombre_persona)
    ubicacion=lugar
    fecha=datetime.datetime.now()
    data=[nombre,fecha,ubicacion]
    empezar("","insert",data)    

def reconocer():
  
    dataPath = './Data' 
    imagePaths = os.listdir(dataPath)
    print('imagePaths=',imagePaths)

    face_recognizer = cv2.face.LBPHFaceRecognizer_create()

    face_recognizer.read('modeloLBPHFace.xml')

    cap = cv2.VideoCapture(0)

    faceClassif = cv2.CascadeClassifier(cv2.data.haarcascades+'haarcascade_frontalface_default.xml')

    contador=0
    denegado=0
    while True:
        global nombre_persona
        ret,frame = cap.read()
        if ret == False: break
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        auxFrame = gray.copy()

        faces = faceClassif.detectMultiScale(gray,1.3,5)

        for (x,y,w,h) in faces:
            rostro = auxFrame[y:y+h,x:x+w]
            rostro = cv2.resize(rostro,(150,150),interpolation= cv2.INTER_CUBIC)
            result = face_recognizer.predict(rostro)

            cv2.putText(frame,'{}'.format(result),(x,y-5),1,1.3,(255,255,0),1,cv2.LINE_AA)

            # LBPHFace
            if result[1] < 70:
                contador+=1
                nombre_persona = imagePaths[result[0]]
                cv2.putText(frame,'{}'.format(imagePaths[result[0]]),(x,y-25),2,1.1,(0,255,0),1,cv2.LINE_AA)
                cv2.rectangle(frame, (x,y),(x+w,y+h),(0,255,0),2)
                reconocido="si"
            else:
                cv2.putText(frame,'Desconocido',(x,y-20),2,0.8,(0,0,255),1,cv2.LINE_AA)
                cv2.rectangle(frame, (x,y),(x+w,y+h),(0,0,255),2)
                reconocido="no"
                denegado+=1

        
        cv2.imshow('Reconocimiento Facial',frame)
        k = cv2.waitKey(1)
        if k == 27 :
            break
        if contador== 15 :
            hora=datetime.datetime.now()
            break
        if denegado==100:
            break    
    persona_reconocida(reconocido)
    cap.release()
    cv2.destroyAllWindows()







###  Guardar nombre Ingresado ###

def guardar_nombre():
    global nombre, Documento
    nombre = entradaNombre.get()
    Documento = entradaDocumento.get()

    if nombre=="":
        nombre = None
    
    if Documento == "":
        Documento = None
    

def iniciar():
    global cap

    if nombre is  None or Documento is None :
        mensaje.set("Ingrese el nombre y el documento de identidad")

    elif not nombre.replace(' ','').isalpha():
        mensaje.set("Ingrese un nombre valido")
    elif not Documento.isdigit():
        mensaje.set("Ingrese un numero de documento valido")
    else:

        api()
        mensaje.set("")

        if openc == 1:
            capturar(nombre)

        elif mediap == 1:
            capturar2(nombre)
        





### variables globales 

nombre = None
Documento = None
cap = None
nombre_persona = None
gym = 0
pric = 0
bibl = 0
openc= None
mediap = None



def biblioteca():
    global gym, pric, bibl
    bibl = 1
    gym = None
    pric = None

    

def principal():
    global gym, pric, bibl
    pric = 1
    bibl = None
    gym = None

def gimnasio():
    global gym, pric, bibl
    gym = 1
    pric = None
    bibl = None
   


def opencv():
    global openc, mediap
    openc = 1
    mediap = None

    
def mediapipe():
    global mediap, openc
    mediap = 1
    openc = None

def Genero():
    empezar("Genero","select","")

def Rol():
    empezar("Rol","select","")

def Carrera():
    empezar("Carrera","select","")

def lugar():
    empezar("Lugares","select","")           



################################   tkinter    ####################################

root = Tk()

root.title("Reconocimiento Facial ")
root.geometry("1000x680")

notebook = ttk.Notebook(root)

notebook.pack(fill='both' , expand='yes')



inicio = ttk.Frame(notebook)
registro = ttk.Frame(notebook)
reconocimiento = ttk.Frame(notebook)


notebook.add(inicio, text='Inicio' )
notebook.add(registro, text='Registro' )
notebook.add(reconocimiento, text='Reconocimiento' )

### Imagen Luis Amigo ###
imgen = Image.open('img/luisamigo.png')
imgen = imgen.resize((480 , 150), Image.ANTIALIAS)

########### interfaz de inicio #################

imageLA2 = ImageTk.PhotoImage(imgen)
lblLA2 = Label(inicio, image=imageLA2)
lblLA2.grid(column=0, row=0, pady=40, columnspan=2, sticky="nsew")

lblsep15 = Label(inicio, text='', height= 2, width=32, font='times 20')
lblsep15.grid(column=0, row=1, padx=5, pady=10 )

lblEntrada = Label(inicio, text='seleccione la entrada', font='times 20')
lblEntrada.grid(column=0, row=2, padx=0, pady=5)

btnBiblio = Button(inicio, text="Biblioteca", width=20, command=biblioteca , bg="#2191C8")
btnBiblio.grid(column=0, row=3, padx=5, pady=10)

btnPrincipal = Button(inicio, text="Entrada Principal", width=20, command=principal , bg="#2191C8")
btnPrincipal.grid(column=0, row=4, padx=5, pady=10)

btnGym = Button(inicio, text="Gimnasio", width=20, command=gimnasio , bg="#2191C8")
btnGym.grid(column=0, row=5, padx=5, pady=10)


lblsep12 = Label(inicio, text='', height= 2, width=32, font='times 20')
lblsep12.grid(column=1, row=1, padx=5, pady=10)

lblModelo = Label(inicio, text='seleccione modelo', font='times 20')
lblModelo.grid(column=1, row=2, padx=0, pady=5)

btnOpenCv = Button(inicio, text="OpenCv", width=20, command=opencv , bg="#2191C8")
btnOpenCv.grid(column=1, row=3, padx=5, pady=10)

btnMediapipe = Button(inicio, text="MediaPipe", width=20, command=mediapipe , bg="#2191C8")
btnMediapipe.grid(column=1, row=4, padx=5, pady=10)

lblModelo = Label(inicio, text='seleccione la grafica', font='times 20')
lblModelo.grid(column=2, row=2, padx=0, pady=6)

btnOpenCv = Button(inicio, text="Genero", width=20, command=Genero , bg="#2191C8")
btnOpenCv.grid(column=2, row=3, padx=5, pady=10)

btnMediapipe = Button(inicio, text="Rol", width=20, command=Rol , bg="#2191C8")
btnMediapipe.grid(column=2, row=4, padx=5, pady=10)

btnMediapipe = Button(inicio, text="Carrera", width=20, command=Carrera , bg="#2191C8")
btnMediapipe.grid(column=2, row=5, padx=5, pady=10)

btnMediapipe = Button(inicio, text="Lugares", width=20, command=lugar, bg="#2191C8")
btnMediapipe.grid(column=2, row=6, padx=5, pady=10)


## Interfaz de Registro


#imagen luis amigo

imageLA3 = ImageTk.PhotoImage(imgen)
lblLA3 = Label(registro, image=imageLA3)
lblLA3.pack(side="top", anchor="n", padx=200, pady=40)



##

lblsep = Label(registro, text='', justify= CENTER, font='times 20').pack(pady=20)

lblNombre = Label(registro, text='Ingrese su nombre', justify= CENTER, font='times 10').pack(pady=5)

# Crear campo de entrada de Nombre
entradaNombre = Entry(registro)
entradaNombre.pack(pady=10)

lblDocumento = Label(registro, text='Ingrese su numero de documento', justify= CENTER, font='times 10').pack(pady=5)

# Crear campo de entrada de Documento
entradaDocumento = Entry(registro)
entradaDocumento.pack(pady=5)

# Crear botón para guardar el nombre
boton1 = Button(registro, text="Guardar", command=guardar_nombre)
boton1.pack(pady=2)

mensaje = StringVar()
lblMensaje = Label(registro, textvariable=mensaje ,justify= CENTER, font='times 10', fg='red').pack(pady=5)


btnIniciar = Button(registro, text="Registrarse", width=45,height=2, command=iniciar, bg="#2191C8")
btnIniciar.pack(pady=2)




##  Interfaz de reconocimiento


## imagen Luis Amigo
imageLA = ImageTk.PhotoImage(imgen)
lblLA = Label(reconocimiento, image=imageLA3)
lblLA.pack(side="top", anchor="n", padx=200, pady=40)



lblsep2 = Label(reconocimiento, text='', justify= CENTER, font='times 20').pack(pady=10)


bienvenido = StringVar()
lblbienvenido = Label(reconocimiento, textvariable=bienvenido ,justify= CENTER, font='times 30', fg='black').pack(pady=5)



infoNombre = StringVar()
lblInfoNombre = Label(reconocimiento, textvariable=infoNombre ,justify= CENTER, font='times 15', fg='black').pack(pady=2)



lblsep3 = Label(reconocimiento, text='', justify= CENTER, font='times 20').pack(pady=60)


## boton reconocer
btnReconocer = Button(reconocimiento, text="Reconocer", width=45,height=2, command=reconocer, bg="#2191C8")
btnReconocer.pack(pady=2)

root.mainloop()

