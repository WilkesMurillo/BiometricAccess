from mysql.connector import Error
import mysql.connector
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd


def insertar(cone,data1):
    data=data1
    connection=cone
    cursor = connection.cursor()
    cursor.execute("""INSERT INTO registro(Nombre, Fecha, Lugar) VALUES (%s, %s, %s)""", data)
    connection.commit()
    print("{} rows inserted.".format(len(data)))

def consultar(grafico,conn):
    connection=conn
    grafica=grafico
    columnas=["Cedula", "Nombre","Genero","Rol","Carrera"]
    lista=[]
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM personas")
    resultados=cursor.fetchall()
    for fila in resultados:
        lista.append(fila)
        df=pd.DataFrame(lista,columns=columnas)
    if grafica=="Genero":       
        x_values = df['Genero'].unique()
        y_values = df['Genero'].value_counts().tolist()
        plt.bar(x_values, y_values)
        plt.show()
        plt.close('all')
    elif grafica=="Carrera":
        x_values = df['Carrera'].unique()
        y_values = df['Carrera'].value_counts().tolist()
        plt.pie(y_values, labels= x_values, autopct="%0.1f %%")
        plt.show()
        plt.close('all')
    elif grafica=="Rol":
        x_values = df['Rol'].unique()
        y_values = df['Rol'].value_counts().tolist()
        plt.pie(y_values, labels= x_values, autopct="%0.1f %%")
        plt.show()
        plt.close('all')
 
def registros(grafico,conn):
    connection=conn
    grafica=grafico
    columnas=["ID", "Nombre","Fecha","Lugar"]
    lista=[]
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM registro")
    resultados=cursor.fetchall()
    for fila in resultados:
        lista.append(fila)
        df=pd.DataFrame(lista,columns=columnas)
    if grafica=="Lugares":       
        x_values = df['Lugar'].unique()
        y_values = df['Lugar'].value_counts().tolist()
        plt.bar(x_values, y_values,color=['red', 'green', 'blue', 'cyan'])
        plt.show()
        plt.close('all')
        x_values = df['Lugar'].unique()
        y_values = df['Lugar'].value_counts().tolist()
        plt.pie(y_values, labels= x_values, autopct="%0.1f %%")
        plt.show()
        plt.close('all')
        
        
        
def empezar(tipoGrafica,Operacion,data):
    try:
        connection = mysql.connector.connect(
            host='localhost',
            port=3306,
            user='root',
            password='',
            db='biometricaccess'
            )

        if connection.is_connected():
            print("Conexión Exitosa a la base de datos \n")
        if Operacion=="insert":
            insertar(connection,data)
        elif Operacion=="select" and tipoGrafica !="Lugares":
            consultar(tipoGrafica,connection)
        elif Operacion=="select" and tipoGrafica =="Lugares":
            registros(tipoGrafica,connection)   
            
    except Error as ex:
        print("Error during connection: {}".format(ex))
    finally:
        if connection.is_connected():
            connection.close()
            print("Connection closed.")